Casey Haynes, Project 2
LISP Interpreter Setup and instructions. 

**IMPORTANT: A .jar file is included in the "out" folder within the folder "li"

The Project was written in Java, thus, run "li.jar" in the current directory. 
To run it using java, type: "java -jar li.jar"

The prompt behaves like CLISP, although as a general rule, nested parentheses do not work, 
and errors are generally unhandled. 
